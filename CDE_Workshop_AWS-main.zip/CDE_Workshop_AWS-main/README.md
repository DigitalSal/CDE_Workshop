# CDE_Workshop_AWS
______________________________________________________________________________________________________________________________________________________
### Repository to keep CDE Workshop exercises. The scripts use s3 as the source of datasets as this is created for CDE on AWS. 
